import axios from "axios";
import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  KeyboardAvoidingView,
  ScrollView,
  Platform,
  Keyboard,
  Alert,
} from "react-native";

import { Card } from "react-native-paper";

export default function CropPredictionScreen() {

  const [prediction, setPrediction] = useState("No prediction yet");

  const [N, setN] = useState("");
  const [P, setP] = useState("");
  const [K, setK] = useState("");
  const [temperature, setTemperature] = useState("");
  const [humidity, setHumidity] = useState("");
  const [ph, setPh] = useState("");
  const [rainfall, setRainfall] = useState("");

  return (

    <KeyboardAvoidingView
      style={{ flex: 1 }}
      behavior={Platform.OS === "ios" ? "padding" : "height"}
    >

      <ScrollView
        contentContainerStyle={styles.container}
        keyboardShouldPersistTaps="handled"
      >

        <Text style={styles.title}>
          🌱 Crop Prediction
        </Text>

        <Text style={styles.subtitle}>
          AI-based smart farming recommendation
        </Text>

        <Card style={styles.card}>

          <TextInput
            style={styles.input}
            placeholder="Nitrogen (N)"
            keyboardType="numeric"
            value={N}
            onChangeText={setN}
          />

          <TextInput
            style={styles.input}
            placeholder="Phosphorus (P)"
            keyboardType="numeric"
            value={P}
            onChangeText={setP}
          />

          <TextInput
            style={styles.input}
            placeholder="Potassium (K)"
            keyboardType="numeric"
            value={K}
            onChangeText={setK}
          />

          <TextInput
            style={styles.input}
            placeholder="Temperature"
            keyboardType="numeric"
            value={temperature}
            onChangeText={setTemperature}
          />

          <TextInput
            style={styles.input}
            placeholder="Humidity"
            keyboardType="numeric"
            value={humidity}
            onChangeText={setHumidity}
          />

          <TextInput
            style={styles.input}
            placeholder="Soil pH"
            keyboardType="numeric"
            value={ph}
            onChangeText={setPh}
          />

          <TextInput
            style={styles.input}
            placeholder="Rainfall"
            keyboardType="numeric"
            value={rainfall}
            onChangeText={setRainfall}
          />

          <TouchableOpacity
            style={styles.button}
            onPress={async () => {

              Keyboard.dismiss();

              if (
                !N ||
                !P ||
                !K ||
                !temperature ||
                !humidity ||
                !ph ||
                !rainfall
              ) {
                Alert.alert(
                  "Missing Values",
                  "Please fill all the fields."
                );
                return;
              }

              try {

                console.log("Sending request...");

                const response = await axios.post(
                  "http://10.97.90.77:5000/predict",
                  {
                    N: Number(N),
                    P: Number(P),
                    K: Number(K),
                    temperature: Number(temperature),
                    humidity: Number(humidity),
                    ph: Number(ph),
                    rainfall: Number(rainfall),
                  }
                );

                console.log("Response:", response.data);

                setPrediction("🌾 " + response.data.crop);

              }
              catch (error) {

                console.log("ERROR:", error);
                console.log("ERROR RESPONSE:", error.response);

                setPrediction("❌ Server Error");

              }

            }}
          >

            <Text style={styles.buttonText}>
              Predict Crop
            </Text>

          </TouchableOpacity>

        </Card>

        <Card style={styles.result}>

          <Text style={styles.resultTitle}>
            Prediction Result
          </Text>

          <Text style={styles.crop}>
            {prediction}
          </Text>

        </Card>

      </ScrollView>

    </KeyboardAvoidingView>

  );

}

const styles = StyleSheet.create({

  container: {
    flexGrow: 1,
    backgroundColor: "#F2F8F1",
    padding: 20,
    paddingBottom: 40,
  },

  title: {
    fontSize: 26,
    fontWeight: "bold",
    color: "#2E7D32",
    marginTop: 20,
  },

  subtitle: {
    color: "gray",
    marginBottom: 20,
  },

  card: {
    padding: 20,
    borderRadius: 18,
  },

  input: {
    borderWidth: 1,
    borderColor: "#ccc",
    borderRadius: 10,
    padding: 12,
    marginBottom: 12,
    backgroundColor: "white",
  },

  button: {
    backgroundColor: "#4CAF50",
    padding: 15,
    borderRadius: 12,
    alignItems: "center",
  },

  buttonText: {
    color: "white",
    fontSize: 18,
    fontWeight: "bold",
  },

  result: {
    marginTop: 20,
    padding: 20,
    alignItems: "center",
    borderRadius: 18,
    marginBottom: 30,
  },

  resultTitle: {
    fontSize: 18,
    fontWeight: "bold",
  },

  crop: {
    fontSize: 25,
    marginTop: 10,
    color: "#2E7D32",
    fontWeight: "bold",
  },

});