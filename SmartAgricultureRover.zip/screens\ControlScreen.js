import React, {useState} from "react";
import { View, Text, StyleSheet, TouchableOpacity } from "react-native";
import { Card } from "react-native-paper";


export default function ControlScreen(){

  const [command,setCommand] = useState("Stopped");


  const sendCommand=(value)=>{
    setCommand(value);
  };


  return(

    <View style={styles.container}>


      <Text style={styles.title}>
        🎮 Rover Control
      </Text>


      <Card style={styles.statusCard}>

        <Text style={styles.statusTitle}>
          Current Command
        </Text>

        <Text style={styles.command}>
          {command}
        </Text>

      </Card>



      <View style={styles.controller}>


        <TouchableOpacity
        style={styles.button}
        onPress={()=>sendCommand("Moving Forward")}
        >
          <Text style={styles.arrow}>⬆️</Text>
        </TouchableOpacity>



        <View style={styles.middleRow}>


          <TouchableOpacity
          style={styles.button}
          onPress={()=>sendCommand("Turning Left")}
          >
            <Text style={styles.arrow}>⬅️</Text>
          </TouchableOpacity>



          <TouchableOpacity
          style={styles.stop}
          onPress={()=>sendCommand("Stopped")}
          >
            <Text style={styles.stopText}>🛑</Text>
          </TouchableOpacity>



          <TouchableOpacity
          style={styles.button}
          onPress={()=>sendCommand("Turning Right")}
          >
            <Text style={styles.arrow}>➡️</Text>
          </TouchableOpacity>


        </View>



        <TouchableOpacity
        style={styles.button}
        onPress={()=>sendCommand("Moving Backward")}
        >
          <Text style={styles.arrow}>⬇️</Text>
        </TouchableOpacity>


      </View>



      <Card style={styles.modeCard}>

        <Text style={styles.modeTitle}>
          Control Mode
        </Text>

        <Text style={styles.mode}>
          Manual Control 🚜
        </Text>


      </Card>



    </View>

  );
}



const styles=StyleSheet.create({


container:{
 flex:1,
 backgroundColor:"#F2F8F1",
 padding:20,
 alignItems:"center",
},


title:{
 fontSize:26,
 fontWeight:"bold",
 color:"#2E7D32",
 marginTop:20,
},


statusCard:{
 width:"100%",
 padding:20,
 marginTop:20,
 alignItems:"center",
 borderRadius:15,
},


statusTitle:{
 fontSize:16,
},


command:{
 fontSize:22,
 fontWeight:"bold",
 color:"#2E7D32",
 marginTop:5,
},


controller:{
 marginTop:40,
 alignItems:"center",
},


middleRow:{
 flexDirection:"row",
 alignItems:"center",
 marginVertical:15,
},


button:{
 width:75,
 height:75,
 borderRadius:40,
 backgroundColor:"#4CAF50",
 justifyContent:"center",
 alignItems:"center",
 margin:10,
},


stop:{
 width:85,
 height:85,
 borderRadius:45,
 backgroundColor:"#E53935",
 justifyContent:"center",
 alignItems:"center",
 margin:10,
},


arrow:{
 fontSize:35,
},


stopText:{
 fontSize:35,
},


modeCard:{
 marginTop:30,
 width:"100%",
 padding:20,
 alignItems:"center",
 borderRadius:15,
},


modeTitle:{
 fontSize:18,
 fontWeight:"bold",
},


mode:{
 marginTop:5,
 fontSize:18,
 color:"#2E7D32",
},


});