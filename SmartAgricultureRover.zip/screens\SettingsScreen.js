import React, {useState} from "react";
import { View, Text, StyleSheet, Switch, TextInput } from "react-native";
import { Card } from "react-native-paper";


export default function SettingsScreen(){

  const [notifications,setNotifications] = useState(true);
  const [autoMode,setAutoMode] = useState(false);


  return(

    <View style={styles.container}>


      <Text style={styles.title}>
        ⚙️ Settings
      </Text>


      <Card style={styles.card}>

        <Text style={styles.heading}>
          🌐 Backend Connection
        </Text>


        <TextInput
          style={styles.input}
          placeholder="Enter server IP address"
          placeholderTextColor="gray"
        />


        <Text style={styles.status}>
          🟢 Server Ready
        </Text>


      </Card>




      <Card style={styles.card}>


        <Text style={styles.heading}>
          🔔 Notifications
        </Text>


        <View style={styles.row}>

          <Text style={styles.text}>
            Sensor Alerts
          </Text>


          <Switch
            value={notifications}
            onValueChange={setNotifications}
          />


        </View>


      </Card>





      <Card style={styles.card}>


        <Text style={styles.heading}>
          🤖 Rover Mode
        </Text>


        <View style={styles.row}>


          <Text style={styles.text}>
            Autonomous Mode
          </Text>


          <Switch
            value={autoMode}
            onValueChange={setAutoMode}
          />


        </View>


      </Card>





      <Card style={styles.card}>


        <Text style={styles.heading}>
          📡 Connection
        </Text>


        <Text style={styles.info}>
          Rover: 🟢 Connected
        </Text>


        <Text style={styles.info}>
          WiFi: Connected
        </Text>


      </Card>



    </View>

  );

}



const styles=StyleSheet.create({

container:{
 flex:1,
 backgroundColor:"#F2F8F1",
 padding:20,
},


title:{
 fontSize:26,
 fontWeight:"bold",
 color:"#2E7D32",
 marginTop:20,
 marginBottom:20,
},


card:{
 padding:20,
 marginBottom:15,
 borderRadius:18,
 elevation:3,
},


heading:{
 fontSize:18,
 fontWeight:"bold",
 marginBottom:15,
},


input:{
 borderWidth:1,
 borderColor:"#ccc",
 borderRadius:10,
 padding:12,
 marginBottom:10,
},


status:{
 color:"green",
 fontSize:16,
},


row:{
 flexDirection:"row",
 justifyContent:"space-between",
 alignItems:"center",
},


text:{
 fontSize:16,
},


info:{
 fontSize:16,
 marginTop:8,
 color:"#2E7D32",
},


});