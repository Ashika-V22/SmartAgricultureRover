from flask import Flask, request, jsonify
from flask_cors import CORS

import joblib
import pandas as pd


app = Flask(__name__)

CORS(app)


# Load trained model

model = joblib.load("../ML_Model/crop_model.pkl")


@app.route("/")
def home():

    return jsonify({
        "message": "Smart Agriculture Rover API Running"
    })



@app.route("/predict", methods=["POST"])
def predict_crop():

    data = request.json


    input_data = pd.DataFrame([{

        "N": data["N"],
        "P": data["P"],
        "K": data["K"],
        "temperature": data["temperature"],
        "humidity": data["humidity"],
        "ph": data["ph"],
        "rainfall": data["rainfall"]

    }])


    prediction = model.predict(input_data)


    return jsonify({

        "crop": prediction[0]

    })



if __name__ == "__main__":
    app.run(
        host="0.0.0.0",
        port=5000,
        debug=True
    )