import pandas as pd
import joblib

from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier

from sklearn.metrics import accuracy_score, classification_report, confusion_matrix


# Load dataset
data = pd.read_csv("crop_dataset.csv")


# Separate features and target

X = data.drop("label", axis=1)
y = data["label"]


# Split dataset

X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.2,
    random_state=42
)


# Create model

model = RandomForestClassifier(
    n_estimators=100,
    random_state=42
)


# Train model

model.fit(
    X_train,
    y_train
)


# Prediction

y_pred = model.predict(X_test)


# Evaluation

accuracy = accuracy_score(
    y_test,
    y_pred
)


print("Accuracy:", accuracy)


print("\nClassification Report:")
print(
    classification_report(
        y_test,
        y_pred
    )
)


print("\nConfusion Matrix:")
print(
    confusion_matrix(
        y_test,
        y_pred
    )
)



# Save trained model

joblib.dump(
    model,
    "crop_model.pkl"
)


print("\nModel saved successfully!")