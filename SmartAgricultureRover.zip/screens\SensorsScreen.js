import React from "react";
import { View, Text, StyleSheet, ScrollView } from "react-native";
import { Card } from "react-native-paper";


export default function SensorsScreen(){

  return(

    <ScrollView style={styles.container}>


      <Text style={styles.title}>
        📊 Live Sensors
      </Text>


      <Text style={styles.subtitle}>
        Real-time monitoring
      </Text>



      <Card style={styles.sensorCard}>

        <Text style={styles.icon}>
          🌡️
        </Text>

        <Text style={styles.value}>
          28°C
        </Text>

        <Text style={styles.label}>
          Temperature
        </Text>

      </Card>




      <Card style={styles.sensorCard}>

        <Text style={styles.icon}>
          💧
        </Text>

        <Text style={styles.value}>
          65%
        </Text>

        <Text style={styles.label}>
          Humidity
        </Text>

      </Card>





      <Card style={styles.sensorCard}>

        <Text style={styles.icon}>
          🌱
        </Text>

        <Text style={styles.value}>
          72%
        </Text>

        <Text style={styles.label}>
          Soil Moisture
        </Text>

      </Card>





      <Card style={styles.sensorCard}>

        <Text style={styles.icon}>
          🔋
        </Text>

        <Text style={styles.value}>
          85%
        </Text>

        <Text style={styles.label}>
          Battery Level
        </Text>

      </Card>





      <Card style={styles.healthCard}>

        <Text style={styles.healthTitle}>
          🌾 Crop Environment Status
        </Text>


        <Text style={styles.good}>
          ✅ Conditions are optimal
        </Text>


      </Card>




    </ScrollView>

  );

}



const styles=StyleSheet.create({


container:{
 flex:1,
 backgroundColor:"#F2F8F1",
 padding:20,
},



title:{
 fontSize:26,
 fontWeight:"bold",
 color:"#2E7D32",
 marginTop:20,
},



subtitle:{
 color:"gray",
 marginBottom:20,
},



sensorCard:{
 padding:25,
 marginBottom:15,
 borderRadius:18,
 alignItems:"center",
 elevation:4,
},



icon:{
 fontSize:35,
},



value:{
 fontSize:30,
 fontWeight:"bold",
 color:"#2E7D32",
},



label:{
 fontSize:17,
 marginTop:5,
},



healthCard:{
 padding:20,
 marginTop:10,
 borderRadius:18,
},



healthTitle:{
 fontSize:18,
 fontWeight:"bold",
},



good:{
 marginTop:10,
 color:"green",
 fontSize:16,
},


});