import React from "react";
import { View, Text, StyleSheet, ScrollView } from "react-native";
import { Card } from "react-native-paper";

export default function HomeScreen() {
  return (
    <ScrollView style={styles.container}>

      <Text style={styles.title}>
        🌾 Smart Agriculture Rover
      </Text>

      <Text style={styles.subtitle}>
        Intelligent Farming Assistant
      </Text>


      {/* Connection Status */}
      <Card style={styles.card}>
        <Text style={styles.cardTitle}>
          Rover Status
        </Text>

        <Text style={styles.connected}>
          🟢 Connected
        </Text>
      </Card>


      {/* Sensor Overview */}
      <Text style={styles.sectionTitle}>
        Live Overview
      </Text>


      <View style={styles.row}>

        <Card style={styles.sensorCard}>
          <Text style={styles.icon}>🌡️</Text>
          <Text style={styles.value}>28°C</Text>
          <Text>Temperature</Text>
        </Card>


        <Card style={styles.sensorCard}>
          <Text style={styles.icon}>💧</Text>
          <Text style={styles.value}>65%</Text>
          <Text>Humidity</Text>
        </Card>

      </View>


      <View style={styles.row}>

        <Card style={styles.sensorCard}>
          <Text style={styles.icon}>🌱</Text>
          <Text style={styles.value}>72%</Text>
          <Text>Soil Moisture</Text>
        </Card>


        <Card style={styles.sensorCard}>
          <Text style={styles.icon}>🔋</Text>
          <Text style={styles.value}>85%</Text>
          <Text>Battery</Text>
        </Card>

      </View>


      {/* Current Mode */}
      <Card style={styles.card}>

        <Text style={styles.cardTitle}>
          Current Mode
        </Text>

        <Text style={styles.mode}>
          🤖 Autonomous Monitoring
        </Text>

      </Card>


    </ScrollView>
  );
}


const styles = StyleSheet.create({

  container:{
    flex:1,
    backgroundColor:"#F2F8F1",
    padding:20,
  },


  title:{
    fontSize:26,
    fontWeight:"bold",
    marginTop:20,
    color:"#2E7D32",
  },


  subtitle:{
    fontSize:16,
    color:"gray",
    marginBottom:20,
  },


  card:{
    padding:20,
    marginBottom:15,
    borderRadius:15,
    elevation:3,
  },


  cardTitle:{
    fontSize:18,
    fontWeight:"bold",
    marginBottom:10,
  },


  connected:{
    fontSize:18,
    color:"green",
  },


  sectionTitle:{
    fontSize:20,
    fontWeight:"bold",
    marginVertical:10,
  },


  row:{
    flexDirection:"row",
    justifyContent:"space-between",
    marginBottom:15,
  },


  sensorCard:{
    width:"47%",
    padding:15,
    alignItems:"center",
    borderRadius:15,
    elevation:3,
  },


  icon:{
    fontSize:30,
  },


  value:{
    fontSize:25,
    fontWeight:"bold",
    marginVertical:5,
  },


  mode:{
    fontSize:16,
    color:"#2E7D32",
  },


});